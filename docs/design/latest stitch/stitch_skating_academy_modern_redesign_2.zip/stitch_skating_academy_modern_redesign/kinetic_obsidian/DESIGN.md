---
name: Kinetic Obsidian
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353943'
  surface-container-lowest: '#0a0e17'
  surface-container-low: '#181b25'
  surface-container: '#1c1f29'
  surface-container-high: '#262a34'
  surface-container-highest: '#31353f'
  on-surface: '#dfe2ef'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dfe2ef'
  inverse-on-surface: '#2c303a'
  outline: '#849495'
  outline-variant: '#3a494b'
  surface-tint: '#00dce6'
  primary: '#e0fdff'
  on-primary: '#00373a'
  primary-container: '#00f2fe'
  on-primary-container: '#006a70'
  inverse-primary: '#00696f'
  secondary: '#41eec1'
  on-secondary: '#00382b'
  secondary-container: '#00d1a6'
  on-secondary-container: '#005441'
  tertiary: '#efffbb'
  on-tertiary: '#283500'
  tertiary-container: '#bdec00'
  on-tertiary-container: '#516800'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ff6ff'
  primary-fixed-dim: '#00dce6'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f53'
  secondary-fixed: '#55fccf'
  secondary-fixed-dim: '#28dfb4'
  on-secondary-fixed: '#002118'
  on-secondary-fixed-variant: '#00513f'
  tertiary-fixed: '#c3f400'
  tertiary-fixed-dim: '#abd600'
  on-tertiary-fixed: '#161e00'
  on-tertiary-fixed-variant: '#3c4d00'
  background: '#0f131c'
  on-background: '#dfe2ef'
  surface-variant: '#31353f'
typography:
  display-hero:
    fontFamily: Syne
    fontSize: 44px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.04em
  display-hero-mobile:
    fontFamily: Syne
    fontSize: 34px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Syne
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Syne
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Syne
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  stat-counter:
    fontFamily: Syne
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 32px
    letterSpacing: -0.02em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '800'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system projects elite athletic performance, surgical precision, and adrenaline-fueled elegance. Built for a world-class roller skating academy, the identity merges precision sports engineering with high-voltage telemetry. The visual language shifts away from casual recreational aesthetics toward an aggressive, high-stakes athletic tech interface designed to evoke speed, calculated motion, and championship mastery.

The visual direction pairs **Dark Mode Minimalism** with **Hyper-Performance Glassmorphism**. Precision-cut surfaces, high-contrast atmospheric dark layers, microscopic glowing telemetry rims, and saturated hyper-luminescent light strikes turn raw biometric and scheduling data into a pro-tier sensory experience. Interactions must feel instant, tactile, and frictionless, tailored directly for high-velocity thumb interaction on trackside mobile screens.

## Colors

The palette leverages high-contrast luminescence over an abyss of deep slate and midnight obsidian.

- **Obsidian Grounds (Neutrals):**
  - Base Ground: `#0A0E17` (Deep track floor)
  - Surface Mid: `#121826` (Elevated card panels)
  - Surface High: `#1A2236` (Interactive targets, active sheets)
  - Ghost Accent / Borders: `rgba(255, 255, 255, 0.08)` to `rgba(255, 255, 255, 0.16)`

- **Electric Accents:**
  - **Ice Cyan (`#00F2FE`):** Primary action anchor, active session states, primary telemetry highlights, and top-tier metrics.
  - **Hyper Teal (`#05D5AA`):** Secondary data stream, positive cadence, velocity markers, and confirmed ledger states.
  - **Electric Volt (`#CCFF00`):** Kinetic micro-triggers, live session indicators, sprint intervals, and streak milestones.
  - **Warning Coral (`#FF4D4D`):** Fatigue alerts, delinquent pass warnings, overdue schedules, and terminal errors.

Text roles demand maximum legibility under intense conditions: Primary Text defaults to `#F8FAFC` (Slate 50), Secondary Text to `#94A3B8` (Slate 400), and Tertiary/Telemetry metadata to `#64748B` (Slate 500).

## Typography

Typography establishes an aggressive athletic cadence. Headings use **Syne** with hyper-tight tracking and assertive structural forms to evoke rapid trajectory and pro tournament stature. Data tables, system UI, and biometric outputs leverage **Plus Jakarta Sans** for crystal clarity under strained lighting conditions.

All telemetry numbers, speed readouts, and lap counters utilize tabular numeral figures (`font-variant-numeric: tabular-nums`) to prevent layout shifting during active telemetry streaming. The `label-caps` token is reserved strictly for status chips, category anchors, track position labels, and barcode metadata.

## Layout & Spacing

The layout is built around a mobile-first athletic cockpit system using an 8-point geometric scale. 

- **Thumb Zone Anchor:** Primary navigation and high-frequency triggers (booking confirm, session check-in, athlete switch) stay locked within the bottom 35% of the mobile viewport.
- **Grids & Breakpoints:**
  - **Mobile (<768px):** 4-column fluid layout with `margin: 1rem` and `gutter: 1rem`. Cards and active athlete carousels extend edge-to-edge with safe-zone bleed.
  - **Tablet (768px–1023px):** 8-column fluid layout with `margin-tablet: 2rem` and `gutter-tablet: 1.5rem`.
  - **Desktop (≥1024px):** 12-column fixed grid with maximum container width of `1280px`, `margin-desktop: 3rem`, and `gutter-desktop: 2rem`.

Internal component padding leverages `space-xs` (4px) and `space-sm` (8px) for condensed badge/metric pairings, `space-md` (16px) for standard interactive cards, and `space-lg` (24px) for prominent modular telemetry pods.

## Elevation & Depth

Visual hierarchy uses physical luminescent refraction over solid shadow offsets. Instead of traditional mud-tinted drop shadows, depth is achieved via layered glass substrates, optical borders, and directional light flares.

- **Level 0 (Floor Canvas):** Solid `#0A0E17`. Raw background container for trackside streaming.
- **Level 1 (Docked Containers & Underlays):** `#121826` with a hairline stroke (`1px solid rgba(255, 255, 255, 0.05)`).
- **Level 2 (Telemetry Panels & Session Cards):** Frosted glass surface using `backdrop-filter: blur(16px)`, surface fill of `rgba(26, 34, 54, 0.65)`, and an inner top highlight border: `1px solid rgba(255, 255, 255, 0.12)`.
- **Level 3 (Floating Action Bars & Athlete HUDs):** High-density glass (`rgba(18, 24, 38, 0.85)`), `backdrop-filter: blur(24px)`, bounded by `1px solid rgba(0, 242, 254, 0.25)` and an ambient glow of `0 8px 32px rgba(0, 242, 254, 0.12)`.
- **Active State Glow:** Focused cards or active passes radiate a multi-stop ambient field: `0 0 24px -4px rgba(0, 242, 254, 0.35)`.

## Shapes

The design system enforces balanced kinetic contours (`roundedness: 2`). Radii scale proportionally from tactical indicators up to major visual containers:

- **Tokens & Metrics Badges:** 0.5rem (8px) corner rounding to maintain structural firmness.
- **Standard Cards, Inputs & Modals:** 1rem (16px) for balanced handheld ergonomics.
- **Hero Containers & Active Session Passes:** 1.5rem (24px) for premium framing.
- **Pills, Tabs & Avatars:** Fully rounded (9999px) for tactile, directional gesture anchors.

## Components

### Buttons
- **Primary Kinetic Action:** Fully rounded or `rounded-xl` button with a gradient fill from `#00F2FE` to `#05D5AA`. Text rendered in `#0A0E17` (Bold Syne/Plus Jakarta Sans). Subtle hover/press scale reduction (`scale-98`) with an ambient cyan bloom (`box-shadow: 0 0 20px rgba(0, 242, 254, 0.4)`).
- **Secondary Ghost:** `#1A2236` surface, `1px solid rgba(255, 255, 255, 0.12)`, text `#F8FAFC`. On press, border illuminates to `#00F2FE`.
- **Tactical Volt:** High-urgency button in `#CCFF00` with `#0A0E17` text for instantaneous sprint triggers or instant-book sessions.

### Athlete Switcher Carousel
- Horizon-scrolling pill dock with frictionless momentum scroll.
- Active athlete displays a radiant `#00F2FE` inner ring, micro-volt dot (`#CCFF00`) denoting live track presence, and dynamic bio-metrics summary chip directly beneath the avatar. Inactive states rest at 50% opacity.

### Active Session Pass
- Hybrid concert-ticket and biometric passport card. Top quadrant contains academy badge, athlete class division, and high-visibility countdown timer.
- Mid-section features a digital punch-out notch with dashed perforation line (`border-t border-dashed border-white/20`).
- Bottom quadrant displays an authentic, high-density SVG tracking barcode / dynamic micro-QR token paired with security hash typography (`label-caps`).

### Glowing Progress Rings & Telemetry Pods
- Multi-channel circular SVG rings illustrating Heart Rate Zone, Lap Pacing, and Session Completion.
- Background track set at `rgba(255, 255, 255, 0.06)`; active indicator strokes incorporate linear gradients (`#00F2FE` to `#CCFF00`) with rounded caps and a drop-shadow glow filter (`drop-shadow(0 0 6px #00F2FE)`).

### Status Badges & Chips
- Compact pill silhouettes with uppercase bold lettering (`label-caps`).
- **Live Now:** `#CCFF00` text, `rgba(204, 255, 0, 0.12)` fill, with an animated pulsing dot indicator.
- **Upcoming:** `#00F2FE` text, `rgba(0, 242, 254, 0.12)` fill.
- **Paid / Confirmed:** `#05D5AA` text, `rgba(5, 213, 170, 0.12)` fill.
- **Overdue / Alert:** `#FF4D4D` text, `rgba(255, 77, 77, 0.12)` fill.

### Input Fields & Controls
- Low-profile inset styling with `#121826` background, `1px solid rgba(255, 255, 255, 0.08)`, and rounded-xl architecture.
- Focus state reveals a crisp `1px solid #00F2FE` edge accompanied by a faint interior ambient halo.
- Checkboxes and toggles employ custom pill shapes; toggled-on states ignite into vibrant `#05D5AA` with tactile micro-spring physics.